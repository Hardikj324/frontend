import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiPlus, FiX } from 'react-icons/fi';
import { ALERT_THRESHOLDS } from '../../utils/constants';
import { useAlerts } from '../../hooks/useAlerts';
import { validateAlertThreshold } from '../../utils/validators';

export default function AlertBuilder() {
  const { addAlert } = useAlerts();
  const [isOpen, setIsOpen] = useState(false);
  const [alertType, setAlertType] = useState('temperature_high');
  const [threshold, setThreshold] = useState(ALERT_THRESHOLDS.TEMP_HIGH);
  const [alertName, setAlertName] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const alertTypes = [
    { value: 'temperature_high', label: '🔥 High Temperature', key: 'TEMP_HIGH' },
    { value: 'temperature_low', label: '❄️ Low Temperature', key: 'TEMP_LOW' },
    { value: 'rain', label: '🌧️ Rain Expected', key: 'RAIN' },
    { value: 'high_wind', label: '💨 High Wind', key: 'WIND' },
    { value: 'aqi_high', label: '💨 High AQI', key: 'AQI_HIGH' },
  ];

  const handleAddAlert = async () => {
    if (!validateAlertThreshold(alertType, threshold)) {
      setMessage('❌ Invalid threshold value');
      return;
    }

    setLoading(true);
    try {
      const newAlert = {
        type: alertType,
        threshold,
        name: alertName || alertTypes.find(a => a.value === alertType).label,
        isActive: true,
      };

      addAlert(newAlert);
      setMessage('✅ Alert created successfully!');
      setTimeout(() => {
        setAlertType('temperature_high');
        setThreshold(ALERT_THRESHOLDS.TEMP_HIGH);
        setAlertName('');
        setIsOpen(false);
        setMessage('');
      }, 1500);
    } catch {
      setMessage('❌ Failed to create alert');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-center gap-2 font-bold py-3.5 rounded-xl transition-all duration-300 ${isOpen ? 'bg-[var(--bg-input)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] border border-[var(--border-input)]' : 'bg-[var(--accent)] text-white hover:opacity-90 shadow-[var(--shadow-md)]'}`}
      >
        {isOpen ? <FiX size={20} /> : <FiPlus size={20} />}
        {isOpen ? 'Cancel Creation' : 'Create New Alert'}
      </button>

      <AnimatePresence>
      {isOpen && (
        <motion.div
          className="mt-4 bg-[var(--bg-input)] border border-[var(--border-input)] rounded-xl p-6 shadow-[var(--shadow-md)] overflow-hidden"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
        >
          <div className="space-y-5">
            {/* Alert Name */}
            <div>
              <label className="text-[var(--text-muted)] text-xs font-bold uppercase tracking-wide block mb-2">Alert Name (Optional)</label>
              <input
                type="text"
                value={alertName}
                onChange={(e) => setAlertName(e.target.value)}
                placeholder="Custom name for this alert"
                className="w-full bg-[var(--bg-card)] border border-[var(--border-card)] focus:border-[var(--accent)] rounded-lg px-4 py-3 text-[var(--text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)] transition-all"
              />
            </div>

            {/* Alert Type & Threshold Row */}
            <div className="flex flex-col md:flex-row gap-5">
                <div className="flex-1">
                  <label className="text-[var(--text-muted)] text-xs font-bold uppercase tracking-wide block mb-2">Alert Type</label>
                  <select
                    value={alertType}
                    onChange={(e) => setAlertType(e.target.value)}
                    className="w-full bg-[var(--bg-card)] border border-[var(--border-card)] focus:border-[var(--accent)] rounded-lg px-4 py-3 text-[var(--text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)] transition-all"
                  >
                    {alertTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex-1">
                  <label className="text-[var(--text-muted)] text-xs font-bold uppercase tracking-wide block mb-2">
                    Threshold Value
                    {alertType.includes('temperature') && ' (°C)'}
                    {alertType.includes('rain') && ' (%)'}
                    {alertType.includes('wind') && ' (km/h)'}
                    {alertType.includes('aqi') && ' (AQI)'}
                  </label>
                  <input
                    type="number"
                    value={threshold}
                    onChange={(e) => setThreshold(parseFloat(e.target.value))}
                    className="w-full bg-[var(--bg-card)] border border-[var(--border-card)] focus:border-[var(--accent)] rounded-lg px-4 py-3 text-[var(--text-primary)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)] transition-all"
                  />
                </div>
            </div>

            {message && (
              <div className={`p-4 rounded-lg text-center font-bold items-center justify-center border ${
                message.includes('✅')
                  ? 'bg-green-500/10 text-green-500 border-green-500/20'
                  : 'bg-red-500/10 text-red-500 border-red-500/20'
              }`}>
                {message}
              </div>
            )}

            <div className="pt-2">
              <button
                onClick={handleAddAlert}
                disabled={loading}
                className="w-full bg-[var(--accent-subtle)] hover:bg-[var(--accent-hover)] border border-[var(--accent)] text-[var(--accent)] disabled:opacity-50 font-bold py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {loading ? 'Creating...' : <><FiPlus size={18} /> Save Alert</>}
              </button>
            </div>
          </div>
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
}