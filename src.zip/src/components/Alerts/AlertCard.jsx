import { motion } from 'framer-motion';
import React from 'react';

import { FiTrash2, FiPower } from 'react-icons/fi';

export default function AlertCard({ alert, onToggle, onDelete }) {
  const getAlertIcon = (type) => {
    switch (type) {
      case 'temperature_high':
        return '🔥';
      case 'temperature_low':
        return '❄️';
      case 'rain':
        return '🌧️';
      case 'high_wind':
        return '💨';
      case 'aqi_high':
        return '💨';
      default:
        return '🔔';
    }
  };

  return (
    <motion.div
      className={`relative overflow-hidden bg-[var(--bg-card)] border rounded-xl p-5 flex items-center justify-between transition-all duration-300 ${
        alert.isActive ? 'border-[var(--accent)] shadow-sm' : 'border-[var(--border-card)] opacity-70'
      }`}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
    >
      {/* Decorative side accent */}
      {alert.isActive && (
          <div className="absolute left-0 top-0 bottom-0 w-1 bg-[var(--accent)]" />
      )}
      
      <div className="flex items-center gap-5 flex-1 pl-2">
        <div className={`flex items-center justify-center w-12 h-12 rounded-full ${alert.isActive ? 'bg-[var(--accent-subtle)]' : 'bg-[var(--bg-input)]'} text-2xl`}>
            {getAlertIcon(alert.type)}
        </div>
        <div className="flex-1">
          <p className="font-bold text-[var(--text-primary)] text-lg leading-tight mb-1">{alert.name}</p>
          <div className="flex items-center gap-3">
             <span className="inline-block px-2.5 py-1 rounded-md bg-[var(--bg-input)] text-[var(--text-secondary)] text-xs font-semibold uppercase tracking-wider">
                Threshold: {alert.threshold}
             </span>
             {!alert.isActive && (
                 <span className="text-red-400 text-xs font-semibold tracking-wide">Disabled</span>
             )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => onToggle(alert.id)}
          className={`p-2.5 rounded-lg transition-colors focus:outline-none ${
            alert.isActive
              ? 'bg-[var(--accent-subtle)] text-[var(--accent)] hover:bg-[var(--accent-hover)]'
              : 'bg-[var(--bg-input)] text-[var(--text-muted)] hover:text-[var(--text-primary)] border border-[var(--border-input)]'
          }`}
          title={alert.isActive ? 'Disable alert' : 'Enable alert'}
        >
          <FiPower size={18} />
        </button>
        <button
          onClick={() => onDelete(alert.id)}
          className="p-2.5 rounded-lg border border-transparent bg-red-500/10 text-red-500 hover:bg-red-500/20 hover:border-red-500/30 transition-colors focus:outline-none"
          title="Delete alert"
        >
          <FiTrash2 size={18} />
        </button>
      </div>
    </motion.div>
  );
}