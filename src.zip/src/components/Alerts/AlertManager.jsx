import { motion } from 'framer-motion';
import React from 'react';

import AlertBuilder from './AlertBuilder';
import AlertCard from './AlertCard';
import { useAlerts } from '../../hooks/useAlerts';
import { FiBellOff } from 'react-icons/fi';

export default function AlertManager() {
  const { alerts, removeAlert, updateAlert } = useAlerts();

  const handleToggleAlert = (id) => {
    const alert = alerts.find((a) => a.id === id);
    if (alert) {
      updateAlert(id, { isActive: !alert.isActive });
    }
  };

  return (
    <motion.div
      className="theme-card rounded-2xl p-6 lg:p-8 shadow-md"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="mb-8">
         <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">Manage Alerts</h2>
         <p className="text-[var(--text-muted)]">Set up notifications for specific weather conditions.</p>
      </div>

      <AlertBuilder />

      <div className="mt-10">
        <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 border-b border-[var(--border-card)] pb-2">Active Alerts</h3>
        
        {alerts.length === 0 ? (
          <div className="text-center py-12 bg-[var(--bg-input)] rounded-xl border border-[var(--border-card)]">
            <FiBellOff className="mx-auto text-4xl text-[var(--text-muted)] mb-3" />
            <p className="text-lg text-[var(--text-primary)] font-semibold mb-1">No alerts configured</p>
            <p className="text-[var(--text-muted)] text-sm max-w-sm mx-auto">Create your first weather alert above to get notified when conditions change.</p>
          </div>
        ) : (
          <motion.div className="space-y-4" layout>
            {alerts.map((alert) => (
              <AlertCard
                key={alert.id}
                alert={alert}
                onToggle={handleToggleAlert}
                onDelete={removeAlert}
              />
            ))}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}