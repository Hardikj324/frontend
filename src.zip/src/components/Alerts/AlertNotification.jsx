import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiX, FiBell } from 'react-icons/fi';

export default function AlertNotification({ notifications = [], onClose }) {
  return (
    <div className="fixed top-24 right-6 z-50 space-y-3 max-w-sm">
      <AnimatePresence mode="popLayout">
        {notifications.map((notification) => (
          <motion.div
            key={notification.id}
            className="bg-dark-card border-2 border-orange-accent/60 rounded-lg p-4 shadow-lg backdrop-blur-md"
            initial={{ opacity: 0, x: 400 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 400 }}
          >
            <div className="flex items-start gap-3">
              <FiBell className="text-orange-accent mt-1 flex-shrink-0" size={20} />
              <div className="flex-1">
                <p className="font-bold text-white">{notification.title}</p>
                <p className="text-gray-400 text-sm">{notification.message}</p>
              </div>
              <button
                onClick={() => onClose(notification.id)}
                className="text-gray-400 hover:text-cyan-primary transition"
              >
                <FiX size={18} />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}