import { motion } from 'framer-motion';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiUser, FiMail, FiLock, FiArrowRight, FiEye, FiEyeOff } from 'react-icons/fi';
import { signup, login } from '../../services/authAPI';
import { useAuthStore } from '../../store/authStore';
import { validateEmail, validatePassword } from '../../utils/validators';

const inputStyle = {
  width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(100,200,255,0.2)',
  borderRadius: '10px', padding: '12px 12px 12px 42px', color: 'white', fontSize: '0.9rem',
  outline: 'none', transition: 'border-color 0.2s', boxSizing: 'border-box',
};

export default function SignupForm() {
  const navigate = useNavigate();
  const { login: storeLogin } = useAuthStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!name || !email || !password || !confirmPassword) { setError('Please fill in all fields'); return; }
    if (!validateEmail(email)) { setError('Please enter a valid email'); return; }
    const pwValidation = validatePassword(password);
    if (!pwValidation.isValid) { setError(pwValidation.message); return; }
    if (password !== confirmPassword) { setError('Passwords do not match'); return; }
    setLoading(true);
    try {
      await signup(name, email, password);
      const loginResponse = await login(email, password);
      storeLogin({ email, name }, loginResponse.access_token, loginResponse.refresh_token);
      navigate('/');
    } catch (err) {
      setError(err.message || 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ icon: Icon, label, type, value, onChange, placeholder, extraStyle = {} }) => (
    <div>
      <label style={{ color: 'rgba(160,180,210,0.7)', fontSize: '0.78rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: '6px' }}>{label}</label>
      <div style={{ position: 'relative' }}>
        <Icon size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(100,200,255,0.5)' }} />
        <input type={type} value={value} onChange={onChange} placeholder={placeholder}
          style={{ ...inputStyle, ...extraStyle }} disabled={loading}
          onFocus={e => e.target.style.borderColor = 'rgba(100,200,255,0.6)'}
          onBlur={e => e.target.style.borderColor = 'rgba(100,200,255,0.2)'}
        />
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      style={{ background: 'rgba(10,25,55,0.85)', border: '1px solid rgba(100,200,255,0.2)', borderRadius: '20px', padding: '2.5rem', backdropFilter: 'blur(20px)', boxShadow: '0 25px 60px rgba(0,0,0,0.4)' }}
    >
      <h2 style={{ fontSize: '1.75rem', fontWeight: '800', color: 'white', marginBottom: '6px' }}>Create account</h2>
      <p style={{ color: 'rgba(160,180,210,0.6)', fontSize: '0.9rem', marginBottom: '2rem' }}>Start tracking weather with Sky Sight</p>

      {error && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          style={{ background: 'rgba(255,80,80,0.1)', border: '1px solid rgba(255,80,80,0.35)', borderRadius: '10px', padding: '12px 14px', marginBottom: '1.25rem' }}>
          <p style={{ color: '#ff6b6b', fontSize: '0.875rem', fontWeight: '600' }}>{error}</p>
        </motion.div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <Field icon={FiUser} label="Name" type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Your name" />
        <Field icon={FiMail} label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" />
        <div>
          <label style={{ color: 'rgba(160,180,210,0.7)', fontSize: '0.78rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: '6px' }}>Password</label>
          <div style={{ position: 'relative' }}>
            <FiLock size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'rgba(100,200,255,0.5)' }} />
            <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Min 8 characters"
              style={{ ...inputStyle, paddingRight: '42px' }} disabled={loading}
              onFocus={e => e.target.style.borderColor = 'rgba(100,200,255,0.6)'}
              onBlur={e => e.target.style.borderColor = 'rgba(100,200,255,0.2)'}
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)}
              style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'rgba(100,200,255,0.5)', cursor: 'pointer', padding: '4px' }}>
              {showPassword ? <FiEyeOff size={16} /> : <FiEye size={16} />}
            </button>
          </div>
        </div>
        <Field icon={FiLock} label="Confirm Password" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Repeat password" />

        <motion.button type="submit" disabled={loading} whileHover={{ scale: loading ? 1 : 1.02 }} whileTap={{ scale: loading ? 1 : 0.98 }}
          style={{ width: '100%', padding: '13px', borderRadius: '10px', border: 'none', background: loading ? 'rgba(100,200,255,0.15)' : 'linear-gradient(135deg, #64c8ff, #0088dd)', color: loading ? 'rgba(100,200,255,0.5)' : 'white', fontWeight: '700', fontSize: '0.95rem', cursor: loading ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginTop: '0.5rem' }}>
          {loading ? 'Creating account...' : <><span>Create Account</span><FiArrowRight size={16} /></>}
        </motion.button>
      </form>

      <p style={{ color: 'rgba(160,180,210,0.5)', fontSize: '0.85rem', textAlign: 'center', marginTop: '1.5rem' }}>
        Already have an account?{' '}
        <button onClick={() => navigate('/login')} style={{ color: '#64c8ff', fontWeight: '700', background: 'none', border: 'none', cursor: 'pointer' }}>Sign in</button>
      </p>
    </motion.div>
  );
}
