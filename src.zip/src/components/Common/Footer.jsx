import React from 'react';
import { FiGithub, FiTwitter, FiMail } from 'react-icons/fi';

export default function Footer() {
  return (
    <footer className="bg-dark-card border-t border-cyan-primary/30 py-8 px-6 mt-12">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-cyan-primary font-bold mb-3">Sky Sight</h3>
            <p className="text-gray-400 text-sm">
              Real-time weather dashboard with interactive globe visualization and personalized alerts.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-cyan-primary font-bold mb-3">Quick Links</h3>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-cyan-primary transition">Home</a></li>
              <li><a href="#" className="hover:text-cyan-primary transition">Forecast</a></li>
              <li><a href="#" className="hover:text-cyan-primary transition">Settings</a></li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="text-cyan-primary font-bold mb-3">Follow Us</h3>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-cyan-primary transition">
                <FiGithub size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-cyan-primary transition">
                <FiTwitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-cyan-primary transition">
                <FiMail size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-cyan-primary/20 pt-6 text-center text-gray-500 text-sm">
          <p>&copy; 2026 Sky Sight. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}