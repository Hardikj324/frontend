import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { FiMapPin, FiHome, FiMap, FiBookmark, FiBell, FiSettings, FiLogOut, FiSun, FiMoon } from 'react-icons/fi';
import { useDarkMode } from '../../hooks/useDarkMode';
import { useAuthStore } from '../../store/authStore';

const navItems = [
  { path: '/', icon: FiHome, label: 'Home' },
  { path: '/forecast', icon: FiMap, label: 'Forecast' },
  { path: '/locations', icon: FiBookmark, label: 'Saved' },
  { path: '/alerts', icon: FiBell, label: 'Alerts' },
  { path: '/settings', icon: FiSettings, label: 'Settings' },
];

export default function Header() {
  const { darkMode, toggleDarkMode } = useDarkMode();
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header style={{
      background: 'var(--bg-header)',
      backdropFilter: 'blur(20px)',
      borderBottom: '1px solid var(--border-primary)',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      transition: 'background 0.3s ease, border-color 0.3s ease',
    }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }} onClick={() => navigate('/')}>
          <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'linear-gradient(135deg, #64c8ff, #0066cc)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <FiMapPin size={18} color="white" />
          </div>
          <span style={{ fontSize: '1.25rem', fontWeight: '800', background: 'linear-gradient(90deg, var(--accent), #a0d8ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', letterSpacing: '-0.5px' }}>
            Sky Sight
          </span>
        </div>

        {/* Nav */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          {navItems.map(({ path, icon: Icon, label }) => {
            const active = location.pathname === path;
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                style={{
                  display: 'flex', alignItems: 'center', gap: '6px',
                  padding: '8px 14px', borderRadius: '8px', border: 'none', cursor: 'pointer',
                  fontSize: '0.85rem', fontWeight: active ? '700' : '500',
                  background: active ? 'var(--accent-hover)' : 'transparent',
                  color: active ? 'var(--accent)' : 'var(--text-secondary)',
                  transition: 'all 0.2s',
                }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'var(--accent-subtle)'; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
              >
                <Icon size={15} />
                <span className="hidden md:inline">{label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {/* Theme toggle button */}
          <button
            onClick={toggleDarkMode}
            title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            style={{
              width: '40px', height: '40px', borderRadius: '10px',
              border: '1px solid var(--border-primary)',
              background: 'var(--accent-subtle)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--accent)',
              transition: 'all 0.25s ease',
              flexShrink: 0,
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = 'var(--accent-hover)';
              e.currentTarget.style.borderColor = 'var(--accent)';
              e.currentTarget.style.boxShadow = '0 0 12px rgba(100,200,255,0.2)';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = 'var(--accent-subtle)';
              e.currentTarget.style.borderColor = 'var(--border-primary)';
              e.currentTarget.style.boxShadow = 'none';
            }}
          >
            {darkMode ? (
              <FiSun size={17} style={{ color: '#fbbf24' }} />
            ) : (
              <FiMoon size={17} style={{ color: 'var(--accent)' }} />
            )}
          </button>

          {user && (
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '6px 12px 6px 6px', borderRadius: '20px', border: '1px solid var(--border-primary)', background: 'var(--accent-subtle)', cursor: 'pointer', transition: 'all 0.2s' }}
              >
                <div style={{ width: '28px', height: '28px', borderRadius: '50%', background: 'linear-gradient(135deg, #64c8ff, #0066cc)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.75rem', fontWeight: '700', color: 'white' }}>
                  {user.name?.charAt(0).toUpperCase()}
                </div>
                <span style={{ fontSize: '0.85rem', color: 'var(--text-primary)', fontWeight: '600' }}>{user.name}</span>
              </button>
              {showUserMenu && (
                <div style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', background: 'var(--bg-dropdown)', border: '1px solid var(--border-primary)', borderRadius: '12px', padding: '6px', minWidth: '160px', backdropFilter: 'blur(20px)', boxShadow: 'var(--shadow-lg)', zIndex: 200 }}>
                  <button
                    onClick={() => { logout(); setShowUserMenu(false); }}
                    style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', borderRadius: '8px', border: 'none', background: 'transparent', color: '#ef4444', cursor: 'pointer', fontSize: '0.85rem', fontWeight: '600' }}
                  >
                    <FiLogOut size={15} /> Sign Out
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
