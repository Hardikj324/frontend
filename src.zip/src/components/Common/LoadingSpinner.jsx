import React from 'react';

export default function LoadingSpinner({ size = 'md' }) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  };

  return (
    <div className="flex justify-center items-center">
      <div className={`relative ${sizeClasses[size]}`}>
        <div className="absolute inset-0 border-4 border-transparent border-t-cyan-primary border-r-cyan-primary rounded-full animate-spin"></div>
        <div
          className="absolute inset-2 border-4 border-transparent border-b-orange-accent rounded-full animate-spin"
          style={{ animationDirection: 'reverse' }}
        ></div>
      </div>
    </div>
  );
}