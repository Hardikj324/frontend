import React from 'react';
import { useDarkMode } from '../../hooks/useDarkMode';
import { MdDarkMode, MdLightMode } from 'react-icons/md';

export default function ThemeToggle() {
  const { darkMode, toggleDarkMode } = useDarkMode();

  return (
    <button
      onClick={toggleDarkMode}
      className="fixed bottom-8 right-8 p-4 rounded-full bg-cyan-primary/20 hover:bg-cyan-primary/40 transition shadow-lg z-40"
      title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
    >
      {darkMode ? (
        <MdLightMode className="text-yellow-400 text-2xl" />
      ) : (
        <MdDarkMode className="text-cyan-primary text-2xl" />
      )}
    </button>
  );
}