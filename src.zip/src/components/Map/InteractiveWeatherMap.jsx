import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { useWeatherStore } from '../../store/weatherStore';
import { useUIStore } from '../../store/uiStore';
import { getWeatherByCoordinates } from '../../services/weatherAPI';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMapPin, FiX, FiPlus, FiMinus } from 'react-icons/fi';
import '../../styles/map.css';

export default function InteractiveWeatherMap() {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const { setWeather, weather } = useWeatherStore();
  const { setMapZoom, setMapCenter } = useUIStore();
  const [markers, setMarkers] = useState([]);
  const [activeLayer, setActiveLayer] = useState('temp');

  useEffect(() => {
    if (map.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
      center: [0, 20],
      zoom: 2,
      pitch: 30,
      bearing: 0,
    });

    map.current.on('click', async (e) => {
      const { lng, lat } = e.lngLat;
      await handleMapClick(lat, lng);
    });

    map.current.on('zoomend', () => {
      setMapZoom(map.current.getZoom());
    });

    map.current.on('moveend', () => {
      const center = map.current.getCenter();
      setMapCenter([center.lng, center.lat]);
    });

    // Add navigation controls
    map.current.addControl(new maplibregl.NavigationControl(), 'top-right');

    return () => {
      if (map.current) {
        map.current.remove();
      }
    };
  }, [setMapZoom, setMapCenter]);

  const handleMapClick = async (lat, lng) => {
    setLoading(true);
    setSelectedLocation({ latitude: lat, longitude: lng });

    try {
      const weatherData = await getWeatherByCoordinates(lat, lng);
      setWeather(weatherData);

      // Add/update marker
      const el = document.createElement('div');
      el.className = 'marker-pulse';
      el.style.backgroundColor = '#FF6B6B';
      el.style.width = '20px';
      el.style.height = '20px';
      el.style.borderRadius = '50%';
      el.style.border = '3px solid white';
      el.style.boxShadow = '0 0 15px #FF6B6B';
      el.style.cursor = 'pointer';

      const popup = new maplibregl.Popup({
        offset: 25,
        className: 'custom-popup',
      }).setHTML(`
        <div class="text-sm">
          <p class="font-bold text-cyan-primary">📍 ${lat.toFixed(2)}°, ${lng.toFixed(2)}°</p>
          <p class="text-orange-accent">${weatherData.current?.temperature}°C</p>
          <p class="text-gray-300">${weatherData.current?.condition_description}</p>
        </div>
      `);

      new maplibregl.Marker(el)
        .setLngLat([lng, lat])
        .setPopup(popup)
        .addTo(map.current);

      setMarkers([...markers, { lat, lng, marker: el }]);
    } catch (error) {
      console.error('Error:', error);
      setSelectedLocation(null);
    } finally {
      setLoading(false);
    }
  };

  const clearMarkers = () => {
    markers.forEach(({ marker }) => {
      if (marker && marker.parentNode) {
        marker.parentNode.removeChild(marker);
      }
    });
    setMarkers([]);
    setSelectedLocation(null);
  };

  const handleZoomIn = () => {
    map.current?.zoomIn();
  };

  const handleZoomOut = () => {
    map.current?.zoomOut();
  };

  return (
    <div className="map-wrapper relative">
      <div ref={mapContainer} className="interactive-map w-full h-[600px] rounded-xl overflow-hidden" />

      {/* Info Popup */}
      <AnimatePresence>
        {selectedLocation && (
          <motion.div
            className="weather-popup absolute top-6 left-6 z-20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-cyan-primary flex items-center gap-2">
                <FiMapPin size={18} />
                {selectedLocation.latitude.toFixed(2)}°, {selectedLocation.longitude.toFixed(2)}°
              </h3>
              <button
                onClick={() => setSelectedLocation(null)}
                className="text-gray-400 hover:text-cyan-primary transition"
              >
                <FiX size={20} />
              </button>
            </div>

            {loading ? (
              <div className="text-cyan-primary text-center py-4">
                <div className="inline-block animate-spin">⏳</div>
                <p className="text-sm mt-2">Fetching weather...</p>
              </div>
            ) : weather ? (
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center bg-dark-bg/50 p-2 rounded">
                  <span className="text-gray-400">Temperature:</span>
                  <span className="font-bold text-orange-accent text-lg">{weather.current?.temperature}°C</span>
                </div>
                <div className="flex justify-between items-center bg-dark-bg/50 p-2 rounded">
                  <span className="text-gray-400">Condition:</span>
                  <span className="font-bold text-white">{weather.current?.condition_description}</span>
                </div>
                <div className="flex justify-between items-center bg-dark-bg/50 p-2 rounded">
                  <span className="text-gray-400">Humidity:</span>
                  <span className="font-bold text-cyan-primary">{weather.current?.humidity}%</span>
                </div>
                <div className="flex justify-between items-center bg-dark-bg/50 p-2 rounded">
                  <span className="text-gray-400">Wind:</span>
                  <span className="font-bold text-blue-400">{Math.round(weather.current?.wind_speed)} km/h</span>
                </div>
              </div>
            ) : null}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Weather Layers Toggle */}
      <div className="weather-layers-control absolute bottom-6 left-6 z-20 flex flex-col gap-2">
        {['temp', 'radar', 'wind', 'clouds'].map((layer) => (
          <button
            key={layer}
            onClick={() => setActiveLayer(layer)}
            className={`layer-btn transition-all ${activeLayer === layer ? 'active' : ''}`}
            title={`${layer.charAt(0).toUpperCase() + layer.slice(1)} Layer`}
          >
            {layer === 'temp' && '🌡️'}
            {layer === 'radar' && '🌧️'}
            {layer === 'wind' && '💨'}
            {layer === 'clouds' && '☁️'}
            <span className="ml-2 hidden md:inline">{layer.charAt(0).toUpperCase() + layer.slice(1)}</span>
          </button>
        ))}
      </div>

      {/* Zoom Controls */}
      <div className="absolute bottom-6 right-6 z-20 flex flex-col gap-2">
        <button
          onClick={handleZoomIn}
          className="p-3 bg-cyan-primary/20 hover:bg-cyan-primary/40 text-cyan-primary rounded-lg transition shadow-lg"
          title="Zoom in"
        >
          <FiPlus size={20} />
        </button>
        <button
          onClick={handleZoomOut}
          className="p-3 bg-cyan-primary/20 hover:bg-cyan-primary/40 text-cyan-primary rounded-lg transition shadow-lg"
          title="Zoom out"
        >
          <FiMinus size={20} />
        </button>
        {markers.length > 0 && (
          <button
            onClick={clearMarkers}
            className="px-3 py-2 bg-red-500/20 hover:bg-red-500/40 text-red-400 rounded-lg transition shadow-lg text-xs font-semibold"
            title="Clear all markers"
          >
            Clear
          </button>
        )}
      </div>

      {/* Marker count */}
      {markers.length > 0 && (
        <div className="absolute top-6 right-6 z-20 bg-dark-card border border-cyan-primary/30 rounded-lg px-4 py-2">
          <p className="text-cyan-primary font-semibold text-sm">
            📍 {markers.length} location{markers.length !== 1 ? 's' : ''} selected
          </p>
        </div>
      )}
    </div>
  );
}