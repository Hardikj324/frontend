import { motion } from 'framer-motion';
import React from 'react';

import { getWeatherIcon } from '../../utils/weatherHelpers';

export default function WeatherPopup({ weather, coordinates, onClose }) {
  if (!weather || !coordinates) return null;

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="bg-dark-card border-2 border-cyan-primary/50 rounded-2xl p-8 max-w-md w-full backdrop-blur-md shadow-2xl"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-start mb-6">
          <div>
            <p className="text-gray-400 text-sm">📍 Location</p>
            <p className="text-xl font-bold text-cyan-primary">
              {coordinates.latitude.toFixed(2)}°, {coordinates.longitude.toFixed(2)}°
            </p>
          </div>
          <p className="text-5xl">{getWeatherIcon(weather.current?.weather_code, weather.current?.is_day)}</p>
        </div>

        <div className="space-y-3 text-sm">
          <div className="bg-dark-bg rounded-lg p-3 border border-cyan-primary/20">
            <p className="text-gray-400">Current Condition</p>
            <p className="text-lg font-bold text-white mt-1">{weather.current?.condition_description}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-dark-bg rounded-lg p-3 border border-orange-accent/20">
              <p className="text-gray-400 text-xs">Temperature</p>
              <p className="text-2xl font-bold text-orange-accent mt-1">{Math.round(weather.current?.temperature)}°</p>
            </div>
            <div className="bg-dark-bg rounded-lg p-3 border border-cyan-primary/20">
              <p className="text-gray-400 text-xs">Humidity</p>
              <p className="text-2xl font-bold text-cyan-primary mt-1">{weather.current?.humidity}%</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-dark-bg rounded-lg p-3 border border-blue-400/20">
              <p className="text-gray-400 text-xs">Wind Speed</p>
              <p className="text-lg font-bold text-blue-400 mt-1">{Math.round(weather.current?.wind_speed)} km/h</p>
            </div>
            <div className="bg-dark-bg rounded-lg p-3 border border-red-400/20">
              <p className="text-gray-400 text-xs">UV Index</p>
              <p className="text-lg font-bold text-red-400 mt-1">{weather.current?.uv_index.toFixed(1)}</p>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 bg-cyan-primary/20 hover:bg-cyan-primary/40 text-cyan-primary font-bold py-3 rounded-lg transition"
        >
          Close
        </button>
      </motion.div>
    </motion.div>
  );
}