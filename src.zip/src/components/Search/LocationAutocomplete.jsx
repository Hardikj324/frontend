import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiMapPin, FiSearch, FiX } from 'react-icons/fi';

export default function LocationAutocomplete({ onSelect }) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedName, setSelectedName] = useState('');
  const debounceTimer = useRef(null);
  const containerRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    if (!query.trim()) {
      setSuggestions([]);
      setIsOpen(false);
      return;
    }

    setIsLoading(true);
    setIsOpen(true);
    debounceTimer.current = setTimeout(async () => {
      try {
        const response = await fetch(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=6&language=en`
        );
        const data = await response.json();
        setSuggestions(data.results || []);
      } catch (error) {
        console.error('Autocomplete error:', error);
        setSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    }, 350);

    return () => { if (debounceTimer.current) clearTimeout(debounceTimer.current); };
  }, [query]);

  const handleSelect = (location) => {
    const displayName = [location.name, location.admin1, location.country].filter(Boolean).join(', ');
    setSelectedName(displayName);
    setQuery('');
    setSuggestions([]);
    setIsOpen(false);
    onSelect(location);
  };

  const handleClear = () => {
    setQuery('');
    setSelectedName('');
    setSuggestions([]);
    setIsOpen(false);
    onSelect(null);
  };

  return (
    <div ref={containerRef} style={{ position: 'relative', width: '100%' }}>
      {/* Search bar */}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        <FiSearch
          size={18}
          style={{
            position: 'absolute', left: '16px',
            color: 'var(--accent)', flexShrink: 0, pointerEvents: 'none',
          }}
        />
        <input
          type="text"
          className="search-input"
          placeholder={selectedName || 'Search city or location…'}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => { if (suggestions.length > 0) setIsOpen(true); }}
          style={{ paddingLeft: '48px' }}
        />
        {/* Loading spinner or clear */}
        {isLoading ? (
          <div style={{
            position: 'absolute', right: '16px',
            width: '18px', height: '18px',
            border: '2px solid var(--border-primary)',
            borderTop: '2px solid var(--accent)',
            borderRadius: '50%',
            animation: 'spin 0.7s linear infinite',
          }} />
        ) : (query || selectedName) ? (
          <button
            onClick={handleClear}
            style={{
              position: 'absolute', right: '12px',
              background: 'var(--accent-subtle)', border: 'none',
              borderRadius: '50%', width: '24px', height: '24px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--text-secondary)',
              transition: 'background 0.2s',
            }}
          >
            <FiX size={13} />
          </button>
        ) : null}
      </div>

      {/* Selected location badge */}
      {selectedName && !query && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            marginTop: '8px',
            display: 'inline-flex', alignItems: 'center', gap: '6px',
            padding: '4px 12px', borderRadius: '20px',
            background: 'var(--accent-subtle)',
            border: '1px solid var(--border-input)',
          }}
        >
          <FiMapPin size={12} style={{ color: 'var(--accent)' }} />
          <span style={{ color: 'var(--accent)', fontSize: '0.8rem', fontWeight: '600' }}>{selectedName}</span>
        </motion.div>
      )}

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && suggestions.length > 0 && (
          <motion.div
            className="search-dropdown"
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.15 }}
            style={{
              position: 'absolute', top: 'calc(100% + 8px)',
              left: 0, right: 0, zIndex: 9999,
            }}
          >
            {suggestions.map((loc, idx) => (
              <button
                key={`${loc.id || idx}`}
                onClick={() => handleSelect(loc)}
                className="search-item"
                style={{
                  width: '100%', textAlign: 'left',
                  padding: '12px 16px', border: 'none', background: 'transparent',
                  display: 'flex', alignItems: 'center', gap: '12px',
                  borderBottom: idx < suggestions.length - 1
                    ? '1px solid var(--border-card)' : 'none',
                  cursor: 'pointer',
                }}
              >
                <div style={{
                  width: '32px', height: '32px', borderRadius: '8px',
                  background: 'var(--accent-subtle)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <FiMapPin size={15} style={{ color: 'var(--accent)' }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontWeight: '600', color: 'var(--text-primary)', fontSize: '0.9rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {loc.name}
                    {loc.admin1 && <span className="search-item-sub" style={{ fontWeight: '400', fontSize: '0.85rem' }}>, {loc.admin1}</span>}
                  </p>
                  <p className="search-item-sub" style={{ fontSize: '0.78rem', marginTop: '2px' }}>
                    {loc.country}{loc.latitude && ` · ${loc.latitude.toFixed(2)}°, ${loc.longitude.toFixed(2)}°`}
                  </p>
                </div>
              </button>
            ))}
          </motion.div>
        )}

        {isOpen && !isLoading && query && suggestions.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="search-dropdown"
            style={{
              position: 'absolute', top: 'calc(100% + 8px)',
              left: 0, right: 0, zIndex: 9999,
              padding: '20px', textAlign: 'center',
            }}
          >
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No places found for "<strong style={{ color: 'var(--text-secondary)' }}>{query}</strong>"</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}