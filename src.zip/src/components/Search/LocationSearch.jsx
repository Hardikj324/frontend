import React, { useState } from 'react';
import { FiSearch, FiX } from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';

export default function LocationSearch({ onSearch, isLoading }) {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const handleClear = () => {
    setQuery('');
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="relative">
        <motion.div
          className="relative bg-dark-card border border-cyan-primary/30 rounded-lg flex items-center px-4 py-3 focus-within:border-cyan-primary/60 transition-all"
          animate={{
            borderColor: isFocused ? 'rgba(100, 200, 255, 0.6)' : 'rgba(100, 200, 255, 0.3)',
          }}
        >
          <FiSearch className="text-gray-400 mr-3" size={20} />
          <input
            type="text"
            placeholder="Search for a location..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            className="flex-1 bg-transparent text-white placeholder-gray-500 outline-none"
            disabled={isLoading}
          />
          <AnimatePresence>
            {query && (
              <motion.button
                type="button"
                onClick={handleClear}
                initial={{ opacity: 0, rotate: -90 }}
                animate={{ opacity: 1, rotate: 0 }}
                exit={{ opacity: 0, rotate: -90 }}
                className="text-gray-400 hover:text-cyan-primary transition"
              >
                <FiX size={20} />
              </motion.button>
            )}
          </AnimatePresence>
        </motion.div>

        {isLoading && (
          <div className="absolute right-4 top-3">
            <div className="animate-spin">⏳</div>
          </div>
        )}
      </div>
    </form>
  );
}