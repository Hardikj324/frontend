import { motion } from 'framer-motion';
import React, { useState, useEffect } from 'react';
import { saveLocations, getUserLocations } from '../../services/locationsAPI';

import { FiSave, FiRefreshCw, FiTrash2 } from 'react-icons/fi';
import LoadingSpinner from '../Common/LoadingSpinner';

export default function SavedLocations() {
  const [slots, setSlots] = useState({ slot1: '', slot2: '', slot3: '', slot4: '' });
  const [loading, setLoading] = useState(false);
  const [fetchingUserLocations, setFetchingUserLocations] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('success');

  useEffect(() => {
    fetchUserLocations();
  }, []);

  const fetchUserLocations = async () => {
    setFetchingUserLocations(true);
    try {
      const data = await getUserLocations();
      setSlots({
        slot1: data.slot1_name || '',
        slot2: data.slot2_name || '',
        slot3: data.slot3_name || '',
        slot4: data.slot4_name || '',
      });
    } catch (error) {
      console.error('Error fetching user locations:', error);
    } finally {
      setFetchingUserLocations(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSlots({ ...slots, [name]: value });
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      await saveLocations(slots.slot1, slots.slot2, slots.slot3, slots.slot4);
      setMessage('✅ Locations saved successfully!');
      setMessageType('success');
      setTimeout(() => setMessage(''), 3000);
    } catch (error) {
      setMessage(`❌ ${error.message || 'Failed to save locations'}`);
      setMessageType('error');
      setTimeout(() => setMessage(''), 3000);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setSlots({ slot1: '', slot2: '', slot3: '', slot4: '' });
  };

  if (fetchingUserLocations) {
    return (
      <div className="bg-dark-card border border-cyan-primary/30 rounded-xl p-6 backdrop-blur-md flex items-center justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <motion.div
      className="bg-dark-card border border-cyan-primary/30 rounded-xl p-6 backdrop-blur-md"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold text-cyan-primary mb-6">⭐ Saved Locations (4 Slots)</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {['slot1', 'slot2', 'slot3', 'slot4'].map((slot, idx) => (
          <div key={slot}>
            <label className="text-gray-400 text-sm block mb-2 font-semibold">Slot {idx + 1}</label>
            <input
              type="text"
              name={slot}
              value={slots[slot]}
              onChange={handleChange}
              placeholder={`Enter city name (e.g., Delhi, London)`}
              className="w-full bg-dark-bg border border-cyan-primary/30 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-primary/60 transition"
              disabled={loading}
            />
          </div>
        ))}
      </div>

      <div className="flex gap-3 mb-4">
        <button
          onClick={handleSave}
          disabled={loading}
          className="flex-1 bg-orange-accent hover:bg-orange-accent/80 disabled:opacity-50 text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2"
        >
          <FiSave size={18} />
          {loading ? 'Saving...' : '💾 Save Locations'}
        </button>

        <button
          onClick={handleClear}
          disabled={loading}
          className="px-4 bg-red-500/20 hover:bg-red-500/40 text-red-400 font-bold rounded-lg transition flex items-center gap-2"
        >
          <FiTrash2 size={18} />
          Clear
        </button>

        <button
          onClick={fetchUserLocations}
          disabled={loading || fetchingUserLocations}
          className="px-4 bg-cyan-primary/20 hover:bg-cyan-primary/40 text-cyan-primary font-bold rounded-lg transition flex items-center gap-2"
        >
          <FiRefreshCw size={18} />
        </button>
      </div>

      {message && (
        <motion.div
          className={`p-3 rounded-lg text-center font-semibold ${
            messageType === 'success'
              ? 'bg-green-500/20 text-green-400 border border-green-500/30'
              : 'bg-red-500/20 text-red-400 border border-red-500/30'
          }`}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
        >
          {message}
        </motion.div>
      )}
    </motion.div>
  );
}