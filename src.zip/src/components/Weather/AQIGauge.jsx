import { motion } from 'framer-motion';
import React from 'react';
import { getAQILevel, getHealthRecommendation } from '../../utils/weatherHelpers';

export default function AQIGauge({ airQuality }) {
  if (!airQuality) return null;
  const aqi = airQuality.aqi_pm25;
  if (aqi === null || aqi === undefined) return null;

  const level = getAQILevel(aqi);
  const recommendation = getHealthRecommendation(aqi);
  const percentage = Math.min((aqi / 300) * 100, 100);
  const circumference = 2 * Math.PI * 38;
  const dashOffset = circumference - (percentage / 100) * circumference;

  const pollutants = [
    { label: 'PM2.5', value: airQuality.pm25, unit: 'µg/m³' },
    { label: 'PM10', value: airQuality.pm10, unit: 'µg/m³' },
    { label: 'NO₂', value: airQuality.nitrogen_dioxide, unit: 'ppb' },
    { label: 'O₃', value: airQuality.ozone, unit: 'ppb' },
  ].filter(p => p.value !== null && p.value !== undefined);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.3 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '20px',
        padding: '1.75rem',
        backdropFilter: 'blur(20px)',
        boxShadow: 'var(--shadow-md)',
        transition: 'background 0.3s, border-color 0.3s',
      }}
    >
      <h2 style={{ color: 'var(--accent)', fontWeight: '800', fontSize: '1rem', marginBottom: '1.5rem', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
        💨 Air Quality Index
      </h2>

      <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '2rem', alignItems: 'center' }}>
        {/* Circular gauge */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
          <svg width="110" height="110" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="var(--accent-subtle)" strokeWidth="8" />
            <motion.circle
              cx="50" cy="50" r="38"
              fill="none"
              stroke={level.color}
              strokeWidth="8"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              strokeLinecap="round"
              transform="rotate(-90 50 50)"
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset: dashOffset }}
              transition={{ duration: 1.5, ease: 'easeOut' }}
              style={{ filter: `drop-shadow(0 0 8px ${level.color}66)` }}
            />
            <text x="50" y="46" textAnchor="middle" style={{ fill: level.color, fontSize: '16px', fontWeight: '900' }}>{Math.round(aqi)}</text>
            <text x="50" y="60" textAnchor="middle" style={{ fill: 'rgba(160,180,210,0.5)', fontSize: '8px', fontWeight: '600' }}>AQI</text>
          </svg>
          <p style={{ color: level.color, fontWeight: '700', fontSize: '0.85rem', textAlign: 'center' }}>{level.label}</p>
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {/* Recommendation */}
          <div style={{ background: level.color + '15', border: `1px solid ${level.color}30`, borderRadius: '12px', padding: '12px 14px' }}>
            <p style={{ color: level.color, fontWeight: '700', fontSize: '0.85rem', marginBottom: '4px' }}>{recommendation.icon} {recommendation.title}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem', lineHeight: '1.5' }}>{recommendation.advice}</p>
          </div>

          {/* Pollutants */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
            {pollutants.map(p => (
              <div key={p.label} style={{ background: 'var(--accent-subtle)', border: '1px solid var(--border-card)', borderRadius: '10px', padding: '10px 12px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.7rem', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{p.label}</p>
                <p style={{ color: 'var(--accent)', fontWeight: '700', fontSize: '0.9rem', marginTop: '2px' }}>{p.value?.toFixed(1)} <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontWeight: '500' }}>{p.unit}</span></p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
