import { motion } from 'framer-motion';
import React from 'react';
import { useWeatherStore } from '../../store/weatherStore';
import { formatTemperature, formatHumidity, formatWindSpeed, formatPressure, formatUVIndex } from '../../utils/formatters';
import { getWeatherIcon, getTemperatureWarning } from '../../utils/weatherHelpers';

const StatCard = ({ label, value, color = 'var(--accent)', delay = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.3, delay }}
    style={{
      background: 'var(--accent-subtle)',
      border: '1px solid var(--border-card)',
      borderRadius: '12px',
      padding: '1rem',
      transition: 'border-color 0.2s, background 0.2s',
    }}
    onMouseEnter={e => {
      e.currentTarget.style.borderColor = 'var(--border-input)';
      e.currentTarget.style.background = 'var(--accent-hover)';
    }}
    onMouseLeave={e => {
      e.currentTarget.style.borderColor = 'var(--border-card)';
      e.currentTarget.style.background = 'var(--accent-subtle)';
    }}
  >
    <p style={{ color: 'var(--text-label)', fontSize: '0.72rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '6px' }}>{label}</p>
    <p style={{ color, fontSize: '1.4rem', fontWeight: '800', lineHeight: 1 }}>{value}</p>
  </motion.div>
);

export default function CurrentWeather() {
  const weather = useWeatherStore((state) => state.weather);
  const loading = useWeatherStore((state) => state.loading);
  const formattedUpdate = useWeatherStore((state) => state.getFormattedLastUpdated());

  if (loading) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-card)', borderRadius: '20px', padding: '2rem', display: 'grid', gap: '1rem' }}>
        {[1,2,3].map(i => (
          <div key={i} style={{ height: '60px', background: 'var(--accent-subtle)', borderRadius: '10px', animation: 'pulse 1.5s ease infinite' }} />
        ))}
      </div>
    );
  }

  if (!weather) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-card)', borderRadius: '20px', padding: '3rem', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)' }}>No weather data available</p>
      </div>
    );
  }

  const { current } = weather;
  const tempWarning = getTemperatureWarning(current.temperature);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '20px',
        padding: '2rem',
        backdropFilter: 'blur(20px)',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-md)',
        transition: 'background 0.3s, border-color 0.3s',
      }}
    >
      {/* Ambient glow */}
      <div style={{ position: 'absolute', top: '-60px', right: '-60px', width: '200px', height: '200px', background: 'radial-gradient(circle, var(--accent-subtle) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* Temp warning */}
      {tempWarning.level !== 'normal' && (
        <div style={{ marginBottom: '1.25rem', padding: '10px 16px', borderRadius: '10px', background: tempWarning.color + '18', borderLeft: `3px solid ${tempWarning.color}` }}>
          <p style={{ color: tempWarning.color, fontWeight: '600', fontSize: '0.875rem' }}>{tempWarning.message}</p>
        </div>
      )}

      {/* Main row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.78rem', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '8px' }}>
            Current Conditions · Updated {formattedUpdate}
          </p>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '12px' }}>
            <p style={{ fontSize: '5rem', fontWeight: '900', lineHeight: 1, background: 'linear-gradient(135deg, var(--accent), #a0d8ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              {formatTemperature(current.temperature)}
            </p>
          </div>
          <p style={{ color: 'var(--text-secondary)', marginTop: '6px', fontSize: '1rem', fontWeight: '500' }}>
            {current.condition_description}
          </p>
          <p style={{ color: 'var(--text-muted)', marginTop: '4px', fontSize: '0.82rem' }}>
            Feels like {formatTemperature(current.feels_like)}
          </p>
        </div>
        <div style={{ fontSize: '6rem', lineHeight: 1, filter: 'drop-shadow(0 0 20px rgba(100,200,255,0.3))' }}>
          {getWeatherIcon(current.weather_code, current.is_day)}
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '0.75rem' }}>
        <StatCard label="Humidity" value={formatHumidity(current.humidity)} delay={0.05} />
        <StatCard label="Wind" value={formatWindSpeed(current.wind_speed)} color="#93c5fd" delay={0.1} />
        <StatCard label="Wind Dir" value={`${Math.round(current.wind_direction)}°`} color="#93c5fd" delay={0.15} />
        <StatCard label="Pressure" value={formatPressure(current.pressure)} delay={0.2} />
        <StatCard label="UV Index" value={formatUVIndex(current.uv_index)} color="#fb923c" delay={0.25} />
        <StatCard label="Visibility" value={`${(current.visibility / 1000).toFixed(1)} km`} delay={0.3} />
        <StatCard label="Time of Day" value={current.is_day ? '☀️ Day' : '🌙 Night'} color="#a78bfa" delay={0.35} />
      </div>
    </motion.div>
  );
}
