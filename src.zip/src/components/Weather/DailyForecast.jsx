import { motion } from 'framer-motion';
import React from 'react';
import { formatDate, formatTemperature } from '../../utils/formatters';
import { getWeatherIcon } from '../../utils/weatherHelpers';

export default function DailyForecast({ daily = [] }) {
  if (!daily || daily.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.2 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '20px',
        padding: '1.75rem',
        backdropFilter: 'blur(20px)',
        boxShadow: 'var(--shadow-md)',
        transition: 'background 0.3s, border-color 0.3s',
      }}
    >
      <h2 style={{ color: 'var(--accent)', fontWeight: '800', fontSize: '1rem', marginBottom: '1.25rem', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
        📅 7-Day Forecast
      </h2>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {daily.slice(0, 7).map((item, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            whileHover={{ backgroundColor: 'rgba(100,200,255,0.06)' }}
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr auto auto auto auto',
              alignItems: 'center',
              gap: '1rem',
              padding: '14px 16px',
              borderRadius: '12px',
              border: '1px solid var(--border-card)',
              background: idx === 0 ? 'var(--accent-subtle)' : 'transparent',
              transition: 'background 0.2s',
              cursor: 'default',
            }}
          >
            <div>
              <p style={{ color: idx === 0 ? 'var(--accent)' : 'var(--text-primary)', fontWeight: idx === 0 ? '700' : '500', fontSize: '0.875rem' }}>
                {idx === 0 ? 'Today' : formatDate(item.date).split(',')[0]}
              </p>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem', marginTop: '2px' }}>{item.condition_description}</p>
            </div>

            <span style={{ fontSize: '1.6rem' }}>{getWeatherIcon(item.weather_code, true)}</span>

            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ color: '#93c5fd', fontSize: '0.75rem' }}>💧</span>
              <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem', fontWeight: '600' }}>{item.precipitation_probability_max}%</span>
            </div>

            <p style={{ color: '#fb923c', fontWeight: '700', fontSize: '0.9rem', textAlign: 'right' }}>
              {formatTemperature(item.temperature_max)}
            </p>
            <p style={{ color: '#93c5fd', fontWeight: '600', fontSize: '0.9rem', textAlign: 'right', opacity: 0.7 }}>
              {formatTemperature(item.temperature_min)}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
