import { motion } from 'framer-motion';
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { formatTime } from '../../utils/formatters';
import { getWeatherIcon } from '../../utils/weatherHelpers';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: 'var(--bg-dropdown)', border: '1px solid var(--border-input)', borderRadius: '10px', padding: '10px 14px', boxShadow: 'var(--shadow-md)' }}>
        <p style={{ color: 'var(--accent)', fontWeight: '700', marginBottom: '4px' }}>{label}</p>
        <p style={{ color: 'var(--text-primary)', fontWeight: '600' }}>{payload[0].value}°C</p>
      </div>
    );
  }
  return null;
};

export default function HourlyForecast({ hourly = [] }) {
  if (!hourly || hourly.length === 0) return null;

  const chartData = hourly.slice(0, 24).map((item) => ({
    time: formatTime(item.time),
    temp: Math.round(item.temperature),
    rain: item.precipitation_probability,
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '20px',
        padding: '1.75rem',
        backdropFilter: 'blur(20px)',
        boxShadow: 'var(--shadow-md)',
        transition: 'background 0.3s, border-color 0.3s',
      }}
    >
      <h2 style={{ color: 'var(--accent)', fontWeight: '800', fontSize: '1rem', marginBottom: '1.25rem', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
        ⏱ Hourly · Next 24h
      </h2>

      {/* Horizontal scroll cards */}
      <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '1rem', marginBottom: '1.5rem', scrollbarWidth: 'none' }}>
        {hourly.slice(0, 24).map((item, idx) => (
          <motion.div
            key={idx}
            whileHover={{ y: -4, scale: 1.04 }}
            transition={{ duration: 0.15 }}
            style={{
              flexShrink: 0,
              background: idx === 0 ? 'var(--accent-hover)' : 'var(--accent-subtle)',
              border: `1px solid ${idx === 0 ? 'var(--border-input-focus)' : 'var(--border-card)'}`,
              borderRadius: '14px',
              padding: '14px 12px',
              minWidth: '90px',
              textAlign: 'center',
              cursor: 'default',
              transition: 'background 0.2s',
            }}
          >
            <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem', fontWeight: '700' }}>{formatTime(item.time)}</p>
            <p style={{ fontSize: '1.8rem', margin: '6px 0' }}>{getWeatherIcon(item.weather_code, item.is_day)}</p>
            <p style={{ color: 'var(--accent)', fontSize: '1.05rem', fontWeight: '800' }}>{Math.round(item.temperature)}°</p>
            <p style={{ color: '#93c5fd', fontSize: '0.7rem', marginTop: '4px' }}>💧 {item.precipitation_probability}%</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.65rem', marginTop: '2px' }}>{Math.round(item.wind_speed)} km/h</p>
          </motion.div>
        ))}
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#64c8ff" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#64c8ff" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border-card)" />
          <XAxis dataKey="time" stroke="var(--border-input)" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
          <YAxis stroke="var(--border-input)" tick={{ fontSize: 11, fill: 'var(--text-muted)' }} />
          <Tooltip content={<CustomTooltip />} />
          <Area type="monotone" dataKey="temp" stroke="#64c8ff" strokeWidth={2.5} fill="url(#tempGradient)" dot={false} isAnimationActive />
        </AreaChart>
      </ResponsiveContainer>
    </motion.div>
  );
}
