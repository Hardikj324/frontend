import { motion } from 'framer-motion';
import React from 'react';

import { getWeatherIcon } from '../../utils/weatherHelpers';
import { formatTemperature } from '../../utils/formatters';
import { FiMapPin, FiWind, FiDroplet } from 'react-icons/fi';

export default function WeatherCard({ weather, location, onClick }) {
  if (!weather) return null;

  return (
    <motion.div
      className="theme-card h-full rounded-2xl p-6 cursor-pointer hover:border-[var(--accent)] transition-all duration-300 shadow-sm hover:shadow-[var(--shadow-glow)]"
      onClick={onClick}
      whileHover={{ y: -5 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex justify-between items-start mb-6">
        <div>
          <div className="flex items-center gap-2 text-[var(--accent)] mb-1">
            <FiMapPin size={16} />
            <p className="font-bold text-lg leading-tight">{location}</p>
          </div>
          <p className="text-[var(--text-muted)] text-xs">
            {weather.current?.latitude.toFixed(2)}°, {weather.current?.longitude.toFixed(2)}°
          </p>
        </div>
        <div className="text-5xl drop-shadow-md">
           {getWeatherIcon(weather.current?.weather_code, weather.current?.is_day)}
        </div>
      </div>

      <div className="space-y-4">
        <div>
           <p className="text-4xl font-extrabold text-[var(--text-primary)] tracking-tight">
             {formatTemperature(weather.current?.temperature)}
           </p>
           <p className="text-[var(--text-secondary)] font-medium mt-1">{weather.current?.condition_description}</p>
        </div>
        
        <div className="flex gap-4 pt-4 border-t border-[var(--border-card)]">
          <div className="flex items-center gap-1.5 text-[var(--accent)] bg-[var(--accent-subtle)] px-3 py-1.5 rounded-lg flex-1 justify-center">
            <FiDroplet size={14} />
            <span className="text-sm font-semibold">{weather.current?.humidity}%</span>
          </div>
          <div className="flex items-center gap-1.5 text-[var(--accent)] bg-[var(--accent-subtle)] px-3 py-1.5 rounded-lg flex-1 justify-center">
             <FiWind size={14} />
            <span className="text-sm font-semibold">{Math.round(weather.current?.wind_speed)} km/h</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}