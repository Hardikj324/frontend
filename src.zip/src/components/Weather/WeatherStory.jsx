import React from 'react';
import { motion } from 'framer-motion';

export default function WeatherStory({ weather }) {
  const story = React.useMemo(() => {
    if (!weather) return '';
    const { current, air_quality } = weather;
    const temp = current.temperature;
    const condition = current.condition_description.toLowerCase();
    const windSpeed = current.wind_speed;
    const aqi = air_quality?.aqi_pm25;

    let narrative = '';

    if (temp >= 35) narrative = '🔥 Scorching hot outside! ';
    else if (temp >= 25) narrative = '☀️ Warm and pleasant! ';
    else if (temp >= 15) narrative = '🌤️ Mild and comfortable. ';
    else if (temp >= 5) narrative = '❄️ Cool and crisp outside. ';
    else narrative = '🥶 Freezing cold! ';

    if (condition.includes('clear') || condition.includes('sunny')) narrative += 'Perfect for outdoor activities. ';
    else if (condition.includes('cloudy')) narrative += 'Cloudy skies today. ';
    else if (condition.includes('rain')) narrative += 'Rainy — bring an umbrella! ';
    else if (condition.includes('snow')) narrative += 'Snowy weather — bundle up! ';
    else if (condition.includes('storm') || condition.includes('thunder')) narrative += 'Thunderstorms expected — stay safe indoors! ';
    else if (condition.includes('fog')) narrative += 'Foggy — drive carefully! ';

    if (windSpeed > 40) narrative += 'Strong winds are blowing. ';
    else if (windSpeed > 20) narrative += 'There\'s a moderate breeze. ';
    else if (windSpeed < 5) narrative += 'The air is still and calm. ';

    if (aqi !== null && aqi !== undefined) {
      if (aqi <= 50) narrative += '✅ Air quality is excellent!';
      else if (aqi <= 100) narrative += '⚠️ Air quality is acceptable.';
      else if (aqi <= 150) narrative += '⚠️ Sensitive groups may be affected.';
      else narrative += '❌ Air quality is poor — limit outdoor activities.';
    }

    return narrative;
  }, [weather]);

  if (!story) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut", delay: 0.1 }}
      style={{
        position: 'relative',
        background: 'linear-gradient(135deg, var(--bg-card) 0%, rgba(30, 41, 59, 0.6) 100%)',
        border: '1px solid var(--border-card)',
        borderRadius: '20px',
        padding: '1.5rem 2rem',
        display: 'flex',
        alignItems: 'center',
        gap: '20px',
        boxShadow: 'var(--shadow-md)',
        overflow: 'hidden',
        cursor: 'default',
        transition: 'transform 0.2s, box-shadow 0.2s, border-color 0.2s',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
        e.currentTarget.style.borderColor = 'var(--border-input)';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'var(--shadow-md)';
        e.currentTarget.style.borderColor = 'var(--border-card)';
      }}
    >
      <div style={{
        position: 'absolute',
        top: '-50%',
        left: '-10%',
        width: '200px',
        height: '200px',
        background: 'radial-gradient(circle, var(--accent) 0%, transparent 70%)',
        opacity: 0.08,
        pointerEvents: 'none',
        filter: 'blur(30px)'
      }} />



      <div style={{ flex: 1, zIndex: 1 }}>
        <h4 style={{
          color: 'var(--text-primary)',
          fontSize: '0.8rem',
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          fontWeight: '800',
          marginBottom: '6px',
          opacity: 0.9
        }}>
          Weather Insight
        </h4>
        <p style={{
          color: 'var(--text-secondary)',
          fontSize: '1rem',
          lineHeight: '1.6',
          fontWeight: '500'
        }}>
          {story}
        </p>
      </div>
    </motion.div>
  );
}