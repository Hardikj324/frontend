import { useState } from 'react';
import { storage } from '../utils/localStorage';

export const useAlerts = () => {
  const [alerts, setAlerts] = useState(storage.getAlerts());
  const [isLoading] = useState(false);

  const addAlert = (alert) => {
    const newAlert = {
      id: Date.now(),
      ...alert,
      createdAt: new Date(),
    };
    const updated = [...alerts, newAlert];
    setAlerts(updated);
    storage.setAlerts(updated);
    return newAlert;
  };

  const removeAlert = (id) => {
    const updated = alerts.filter((a) => a.id !== id);
    setAlerts(updated);
    storage.setAlerts(updated);
  };

  const updateAlert = (id, updatedAlert) => {
    const updated = alerts.map((a) => (a.id === id ? { ...a, ...updatedAlert } : a));
    setAlerts(updated);
    storage.setAlerts(updated);
  };

  return {
    alerts,
    isLoading,
    addAlert,
    removeAlert,
    updateAlert,
    clearAllAlerts: () => {
      setAlerts([]);
      storage.setAlerts([]);
    },
  };
};