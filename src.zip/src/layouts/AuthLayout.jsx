import React from 'react';
import { Outlet } from 'react-router-dom';
import { FiMapPin } from 'react-icons/fi';

export default function AuthLayout() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #060f1e 0%, #0a1830 50%, #0d2040 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background orbs */}
      <div style={{ position: 'absolute', top: '15%', left: '10%', width: '300px', height: '300px', background: 'radial-gradient(circle, rgba(100,200,255,0.06) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', bottom: '10%', right: '8%', width: '400px', height: '400px', background: 'radial-gradient(circle, rgba(0,100,200,0.06) 0%, transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: '420px', position: 'relative', zIndex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', justifyContent: 'center', marginBottom: '2.5rem' }}>
          <div style={{ width: '42px', height: '42px', borderRadius: '12px', background: 'linear-gradient(135deg, #64c8ff, #0066cc)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FiMapPin size={20} color="white" />
          </div>
          <span style={{ fontSize: '1.75rem', fontWeight: '900', background: 'linear-gradient(90deg, #64c8ff, #a0d8ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', letterSpacing: '-0.5px' }}>
            Sky Sight
          </span>
        </div>
        <Outlet />
      </div>
    </div>
  );
}
