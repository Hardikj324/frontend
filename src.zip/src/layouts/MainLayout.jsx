import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../components/Common/Header';
import ErrorBoundary from '../components/Common/ErrorBoundary';

export default function MainLayout() {
  return (
    <ErrorBoundary>
      <div style={{ minHeight: '100vh', background: 'var(--gradient-body)', display: 'flex', flexDirection: 'column', transition: 'background 0.3s ease' }}>
        <Header />
        <main style={{ flex: 1 }}>
          <Outlet />
        </main>
      </div>
    </ErrorBoundary>
  );
}
