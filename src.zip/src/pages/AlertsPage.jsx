import { motion } from 'framer-motion';
import React from 'react';
import AlertManager from '../components/Alerts/AlertManager';
import { FiBell } from 'react-icons/fi';


export default function AlertsPage() {
  return (
    <motion.div
      className="container mx-auto px-6 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-[var(--accent-subtle)] rounded-lg">
          <FiBell className="text-3xl text-[var(--accent)]" />
        </div>
        <h1 className="text-3xl font-bold text-[var(--text-primary)]">Weather Alerts</h1>
      </div>
      <AlertManager />
    </motion.div>
  );
}