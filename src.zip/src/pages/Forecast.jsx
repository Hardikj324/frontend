import { motion, AnimatePresence } from 'framer-motion';
import React, { useState } from 'react';
import { useWeatherStore } from '../store/weatherStore';
import { useNavigate } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatDate, formatTemperature, formatTime, formatUVIndex } from '../utils/formatters';
import { getWeatherIcon } from '../utils/weatherHelpers';
import { FiArrowLeft, FiSunrise, FiSunset, FiWind, FiSun } from 'react-icons/fi';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length >= 2) {
    return (
      <div style={{ background: 'var(--bg-dropdown)', border: '1px solid var(--border-input)', borderRadius: '10px', padding: '10px 14px', boxShadow: 'var(--shadow-md)' }}>
        <p style={{ color: 'var(--accent)', fontWeight: '700', marginBottom: '4px' }}>{label}</p>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <p style={{ color: '#fb923c', fontWeight: '600' }}>Max: {payload[0].value}°C</p>
          <p style={{ color: '#93c5fd', fontWeight: '600' }}>Min: {payload[1].value}°C</p>
        </div>
      </div>
    );
  }
  return null;
};

export default function Forecast() {
  const navigate = useNavigate();
  const weather = useWeatherStore((state) => state.weather);
  const loading = useWeatherStore((state) => state.loading);

  const [activeTab, setActiveTab] = useState('chart');

  if (!weather && !loading) {
    return (
      <motion.div
        className="container mx-auto px-6 py-12"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}
      >
        <div style={{
          background: 'var(--bg-card)', border: '1px solid var(--border-card)',
          borderRadius: '24px', padding: '3rem 2rem', textAlign: 'center', maxWidth: '400px', width: '100%',
          boxShadow: 'var(--shadow-lg)'
        }}>
          <div style={{ fontSize: '3rem', marginBottom: '1rem', color: 'var(--text-muted)' }}>📍</div>
          <p style={{ color: 'var(--text-primary)', fontSize: '1.25rem', fontWeight: '700', marginBottom: '8px' }}>No Data Available</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '2rem' }}>Please search for a location on the Dashboard to view the extended forecast.</p>
          <button 
            onClick={() => navigate('/')}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
              width: '100%', padding: '12px', borderRadius: '12px', border: 'none',
              background: 'var(--accent-subtle)', color: 'var(--accent)', fontWeight: '700',
              cursor: 'pointer', transition: 'background 0.2s'
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--accent-subtle)'}
          >
            <FiArrowLeft /> Go to Dashboard
          </button>
        </div>
      </motion.div>
    );
  }

  const { daily_forecast } = weather || {};
  if (!daily_forecast) return null;

  const chartData = daily_forecast.slice(0, 7).map(day => ({
    name: formatDate(day.date).split(',')[0],
    max: Math.round(day.temperature_max),
    min: Math.round(day.temperature_min),
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      style={{ maxWidth: '1400px', margin: '0 auto', padding: '2rem 1.5rem' }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <h1 style={{ color: 'var(--text-primary)', fontSize: '2rem', fontWeight: '800' }}>
          7-Day <span style={{ color: 'var(--accent)' }}>Forecast</span>
        </h1>
        
        <div style={{ display: 'flex', background: 'var(--bg-card)', padding: '4px', borderRadius: '14px', border: '1px solid var(--border-card)' }}>
          <button
            onClick={() => setActiveTab('chart')}
            style={{ padding: '8px 20px', borderRadius: '10px', border: 'none', background: activeTab === 'chart' ? 'var(--accent-subtle)' : 'transparent', color: activeTab === 'chart' ? 'var(--accent)' : 'var(--text-muted)', fontWeight: '600', cursor: 'pointer', transition: 'all 0.2s' }}
          >
            Trend Chart
          </button>
          <button
            onClick={() => setActiveTab('details')}
            style={{ padding: '8px 20px', borderRadius: '10px', border: 'none', background: activeTab === 'details' ? 'var(--accent-subtle)' : 'transparent', color: activeTab === 'details' ? 'var(--accent)' : 'var(--text-muted)', fontWeight: '600', cursor: 'pointer', transition: 'all 0.2s' }}
          >
            Detailed View
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'chart' ? (
          <motion.div
            key="chart"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.3 }}
            style={{ background: 'var(--bg-card)', border: '1px solid var(--border-card)', borderRadius: '24px', padding: '2rem', boxShadow: 'var(--shadow-md)' }}
          >
            <h2 style={{ color: 'var(--text-secondary)', fontSize: '1.2rem', fontWeight: '700', marginBottom: '2rem' }}>Temperature Overview</h2>
            <div style={{ width: '100%', height: 400 }}>
              <ResponsiveContainer>
                <AreaChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorMax" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#fb923c" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#fb923c" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorMin" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#93c5fd" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#93c5fd" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" stroke="var(--border-input)" tick={{fill: 'var(--text-muted)'}} />
                  <YAxis stroke="var(--border-input)" tick={{fill: 'var(--text-muted)'}} />
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-card)" vertical={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="max" stroke="#fb923c" strokeWidth={3} fillOpacity={1} fill="url(#colorMax)" activeDot={{ r: 6, fill: '#fb923c' }} />
                  <Area type="monotone" dataKey="min" stroke="#93c5fd" strokeWidth={3} fillOpacity={1} fill="url(#colorMin)" activeDot={{ r: 6, fill: '#93c5fd' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="details"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}
          >
            {daily_forecast.slice(0, 7).map((day, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                style={{
                  background: 'var(--bg-card)', border: '1px solid var(--border-card)',
                  borderRadius: '20px', padding: '1.5rem', display: 'flex', flexDirection: 'column',
                  gap: '1.25rem', transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'default',
                  position: 'relative', overflow: 'hidden'
                }}
                onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; }}
                onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
              >
                {idx === 0 && (
                  <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '4px', background: 'var(--accent)' }} />
                )}

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <h3 style={{ color: idx === 0 ? 'var(--accent)' : 'var(--text-primary)', fontSize: '1.25rem', fontWeight: '800' }}>
                      {idx === 0 ? 'Today' : formatDate(day.date)}
                    </h3>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '4px' }}>{day.condition_description}</p>
                  </div>
                  <div style={{ fontSize: '3rem', lineHeight: 1, filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.1))' }}>
                    {getWeatherIcon(day.weather_code, true)}
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', background: 'var(--accent-subtle)', borderRadius: '12px', padding: '12px' }}>
                  <div>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem', textTransform: 'uppercase', fontWeight: '700', marginBottom: '2px' }}>Temperature</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ color: '#fb923c', fontSize: '1.1rem', fontWeight: '800' }}>↑{formatTemperature(day.temperature_max).replace('°C','')}</span>
                      <span style={{ color: '#93c5fd', fontSize: '0.9rem', fontWeight: '600' }}>↓{formatTemperature(day.temperature_min).replace('°C','')}</span>
                      <span style={{ color: 'var(--text-secondary)', fontSize: '0.8rem', fontWeight: '600' }}>°C</span>
                    </div>
                  </div>
                  <div>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.72rem', textTransform: 'uppercase', fontWeight: '700', marginBottom: '2px' }}>Precipitation</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <span style={{ color: '#60a5fa', fontSize: '0.8rem' }}>💧</span>
                      <span style={{ color: 'var(--accent)', fontSize: '1.1rem', fontWeight: '800' }}>{Math.round(day.precipitation_probability_max)}%</span>
                    </div>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', borderTop: '1px solid var(--border-card)', paddingTop: '1rem', marginTop: 'auto' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)' }}>
                    <FiSunrise style={{ color: '#fbbf24', fontSize: '1.1rem' }} />
                    <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>{day.sunrise ? formatTime(day.sunrise) : '--:--'}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)' }}>
                    <FiSunset style={{ color: '#f87171', fontSize: '1.1rem' }} />
                    <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>{day.sunset ? formatTime(day.sunset) : '--:--'}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)' }}>
                    <FiWind style={{ color: '#9ca3af', fontSize: '1.1rem' }} />
                    <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>{Math.round(day.wind_speed_max)} km/h</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-secondary)' }}>
                    <FiSun style={{ color: '#ea580c', fontSize: '1.1rem' }} />
                    <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>UV {formatUVIndex(day.uv_index_max)}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}