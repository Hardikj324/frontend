import { motion } from 'framer-motion';
import React, { useState } from 'react';
import { useGeolocation } from '../hooks/useGeolocation';
import { useWeather } from '../hooks/useWeather';
import CurrentWeather from '../components/Weather/CurrentWeather';
import HourlyForecast from '../components/Weather/HourlyForecast';
import DailyForecast from '../components/Weather/DailyForecast';
import AQIGauge from '../components/Weather/AQIGauge';
import WeatherStory from '../components/Weather/WeatherStory';
import LoadingSpinner from '../components/Common/LoadingSpinner';
import LocationAutocomplete from '../components/Search/LocationAutocomplete';
import { FiMapPin, FiRefreshCw, FiNavigation } from 'react-icons/fi';

export default function Home() {
  const { location: geoLocation, error: geoError, loading: geoLoading } = useGeolocation();


  const [searchedLocation, setSearchedLocation] = useState(null);

  // Use searched location coords if available, otherwise fall back to geo coords
  const activeLocation = searchedLocation
    ? { latitude: searchedLocation.latitude, longitude: searchedLocation.longitude, name: searchedLocation.name }
    : geoLocation
      ? { ...geoLocation, name: null }
      : null;

  const { weather, loading: weatherLoading, error: weatherError } = useWeather(
    activeLocation?.latitude,
    activeLocation?.longitude
  );

  const handleSearchSelect = (loc) => {
    if (loc) {
      setSearchedLocation(loc);
    } else {
      setSearchedLocation(null); // Cleared — fall back to geolocation
    }
  };

  const handleUseMyLocation = () => {
    setSearchedLocation(null);
  };

  if (geoLoading && !searchedLocation) {
    return (
      <div style={{ minHeight: '80vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '20px' }}>
        <LoadingSpinner size="lg" />
        <p style={{ color: 'var(--text-muted)', fontSize: '1rem' }}>Locating you…</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '2rem 1.5rem' }}>

      {/* ── Search bar ──────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        style={{ marginBottom: '1.25rem' }}
      >
        <LocationAutocomplete onSelect={handleSearchSelect} />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '1.75rem', flexWrap: 'wrap' }}
      >
        {activeLocation && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '6px',
            padding: '5px 14px', borderRadius: '20px',
            background: 'var(--accent-subtle)',
            border: '1px solid var(--border-input)',
          }}>
            <FiMapPin size={12} style={{ color: 'var(--accent)' }} />
            <span style={{ color: 'var(--accent)', fontSize: '0.8rem', fontWeight: '600' }}>
              {searchedLocation
                ? `${searchedLocation.name}${searchedLocation.admin1 ? `, ${searchedLocation.admin1}` : ''}, ${searchedLocation.country}`
                : `${activeLocation.latitude.toFixed(3)}°N, ${activeLocation.longitude.toFixed(3)}°E`
              }
            </span>
          </div>
        )}

        {searchedLocation && geoLocation && (
          <button
            onClick={handleUseMyLocation}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: '6px',
              padding: '5px 14px', borderRadius: '20px', border: 'none', cursor: 'pointer',
              background: 'var(--accent-subtle)', color: 'var(--text-secondary)',
              fontSize: '0.8rem', fontWeight: '600',
              transition: 'all 0.2s',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--accent-subtle)'}
          >
            <FiNavigation size={12} /> Use my location
          </button>
        )}

        {/* Geo error banner (only if no search override) */}
        {geoError && !searchedLocation && (
          <div style={{
            width: '100%', padding: '10px 16px', borderRadius: '10px',
            background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)',
          }}>
            <p style={{ color: '#ef4444', fontSize: '0.85rem' }}>
              📍 {geoError} — Use the search above to find a city.
            </p>
          </div>
        )}

        {/* No location at all */}
        {!activeLocation && !geoLoading && (
          <div style={{
            width: '100%', padding: '16px', borderRadius: '12px', textAlign: 'center',
            background: 'var(--bg-card)', border: '1px solid var(--border-card)',
          }}>
            <p style={{ color: 'var(--text-muted)', marginBottom: '4px' }}>🌍 Search for a city to see weather</p>
          </div>
        )}
      </motion.div>

      {/* ── Weather content ───────────────────────── */}
      {activeLocation && (
        <>
          {weatherLoading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '6rem 0' }}>
              <LoadingSpinner size="lg" />
            </div>
          ) : weatherError ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              style={{
                background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.25)',
                borderRadius: '16px', padding: '2rem', textAlign: 'center',
              }}
            >
              <p style={{ color: '#ef4444', fontWeight: '600', marginBottom: '8px' }}>⚠️ Weather data unavailable</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{weatherError}</p>
            </motion.div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <CurrentWeather />
              {weather && <WeatherStory weather={weather} />}
              {weather && <HourlyForecast hourly={weather.hourly_forecast} />}
              {weather && <DailyForecast daily={weather.daily_forecast} />}
              {weather && <AQIGauge airQuality={weather.air_quality} />}
            </div>
          )}
        </>
      )}
    </div>
  );
}
