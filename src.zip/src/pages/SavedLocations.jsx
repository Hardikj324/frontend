import React, { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FiStar, FiRefreshCw, FiMapPin, FiPlus, FiAlertCircle } from 'react-icons/fi';

import { getSavedLocationsWeather } from '../services/weatherAPI';
import WeatherCard from '../components/Weather/WeatherCard';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 24 } }
};

export default function SavedLocationsPage() {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchSavedLocations = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getSavedLocationsWeather();
      setLocations(data?.locations || []);
      setError(null);
    } catch (err) {
      setError(err.message || 'Failed to sync weather data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSavedLocations();
  }, [fetchSavedLocations]);

  return (
    <motion.div
      className="container mx-auto px-4 md:px-8 py-10 md:py-14 max-w-7xl"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      {/* Header section */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-20px gap-6 bg-[var(--bg-card)] border border-[var(--border-card)] p-6 md:p-8 rounded-3xl shadow-sm" style={{ marginBottom: '20px' }}>
        <div className="flex items-center gap-5">
          <div className="p-4 bg-[var(--accent-subtle)] rounded-2xl shadow-inner flex items-center justify-center">
            <FiStar className="text-3xl text-[var(--accent)]" fill="currentColor" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-[var(--text-primary)] tracking-tight mb-1">Saved Locations</h1>
            <p className="text-[var(--text-muted)] text-sm md:text-base font-medium">Your personal weather dashboard</p>
          </div>
        </div>

        <div className="flex gap-3 w-full sm:w-auto mt-4 sm:mt-0">
          <button
            onClick={fetchSavedLocations}
            disabled={loading}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-6 py-3 md:px-8 md:py-3.5 bg-[var(--accent-subtle)] hover:bg-[var(--accent-hover)] text-[var(--accent)] border border-[var(--border-input)] rounded-2xl transition-all duration-200 active:scale-95 disabled:opacity-50"
          >
            <FiRefreshCw className={`text-lg ${loading ? 'animate-spin' : ''}`} />
            <span className="mr-[20px] font-bold text-[0.95rem] tracking-wide">SYNC DATA</span>
          </button>
        </div>
      </header>

      <AnimatePresence mode="wait">
        {loading && locations.length === 0 ? (
          <motion.div
            key="loading"
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-[300px] rounded-[2rem] bg-[var(--bg-card)] border border-[var(--border-card)] animate-pulse shadow-sm" />
            ))}
          </motion.div>
        ) : error ? (
          <motion.div
            key="error"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-xl mx-auto p-10 rounded-[2.5rem] bg-red-500/10 border border-red-500/20 text-center backdrop-blur-md shadow-lg"
          >
            <FiAlertCircle className="mx-auto text-5xl text-red-500 mb-5" />
            <h3 className="text-2xl font-bold text-red-500 mb-2">Sync Failed</h3>
            <p className="text-red-400/80 text-md mb-8">{error}</p>
            <button
              onClick={fetchSavedLocations}
              className="px-8 py-3.5 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all active:scale-95 shadow-md shadow-red-500/20"
            >
              Try Again
            </button>
          </motion.div>
        ) : locations.length === 0 ? (
          <motion.div
            key="empty"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full relative"
          >
            <div className="flex flex-col items-center justify-center min-h-[450px] p-12 md:p-20 rounded-[3rem] border-2 border-dashed border-[var(--border-input)] bg-[var(--bg-card)]/30 backdrop-blur-sm">
              <motion.div
                initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', delay: 0.1 }}
                className="w-24 h-24 rounded-full bg-[var(--accent-subtle)] border border-[var(--border-input)] shadow-inner flex items-center justify-center text-[var(--accent)] mb-8"
              >
                <FiMapPin size={44} />
              </motion.div>

              <h2 className="text-3xl font-extrabold text-[var(--text-primary)] mb-4 text-center">No saved locations</h2>
              <p className="text-[var(--text-muted)] text-center text-lg max-w-md mx-auto mb-10 leading-relaxed">
                Start building your weather list by searching for cities on the dashboard and saving them here.
              </p>

              <Link
                to="/"
                className="flex items-center justify-center gap-3 px-10 py-4 bg-[var(--accent)] text-white rounded-2xl font-bold text-lg hover:-translate-y-1 hover:shadow-xl hover:shadow-[var(--accent)]/30 transition-all duration-300"
              >
                <FiPlus className="text-xl" /> Add Location
              </Link>
            </div>

            {/* Decorative background glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-[var(--accent)] rounded-full blur-[120px] opacity-5 pointer-events-none -z-10" />
          </motion.div>
        ) : (
          <motion.div
            key="grid"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {locations.map((location, idx) => (
              <motion.div key={location.id || idx} variants={itemVariants} className="h-full group">
                <div className="h-full transition-transform duration-300 group-hover:-translate-y-2">
                  <WeatherCard
                    weather={location.current_weather_data}
                    location={location.name}
                  />
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}