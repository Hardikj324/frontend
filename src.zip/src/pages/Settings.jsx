import { motion } from 'framer-motion';
import React from 'react';
import { useDarkMode } from '../hooks/useDarkMode';
import { useAuthStore } from '../store/authStore';

import { FiLogOut, FiSettings, FiUser, FiMoon, FiSun } from 'react-icons/fi';

export default function Settings() {
  const { darkMode, toggleDarkMode } = useDarkMode();
  const { user, logout } = useAuthStore();

  return (
    <motion.div
      className="container mx-auto px-6 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="flex items-center gap-3 mb-8">
        <FiSettings className="text-3xl text-[var(--accent)]" />
        <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight">Settings</h1>
      </div>

      <div className="max-w-2xl space-y-6">
        {/* User Info */}
        <motion.div
          className="theme-card rounded-2xl p-6 shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-[var(--accent-subtle)] rounded-lg">
              <FiUser className="text-[var(--accent)] text-xl" />
            </div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">User Profile</h2>
          </div>
          
          {user && (
            <div className="space-y-4">
              <div className="bg-[var(--bg-input)] p-4 rounded-xl border border-[var(--border-input)]">
                <p className="text-[var(--text-muted)] text-xs font-semibold uppercase tracking-wider mb-1">Name</p>
                <p className="text-[var(--text-primary)] font-semibold text-lg">{user.name}</p>
              </div>
              <div className="bg-[var(--bg-input)] p-4 rounded-xl border border-[var(--border-input)]">
                <p className="text-[var(--text-muted)] text-xs font-semibold uppercase tracking-wider mb-1">Email</p>
                <p className="text-[var(--text-primary)] font-semibold text-lg">{user.email}</p>
              </div>
            </div>
          )}
        </motion.div>

        {/* Theme Settings */}
        <motion.div
          className="theme-card rounded-2xl p-6 shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-[var(--accent-subtle)] rounded-xl text-[var(--accent)]">
                 {darkMode ? <FiMoon size={24} /> : <FiSun size={24} />}
              </div>
              <div>
                <h2 className="text-xl font-bold text-[var(--text-primary)]">Appearance</h2>
                <p className="text-[var(--text-muted)] text-sm mt-1">Toggle dark/light theme</p>
              </div>
            </div>
            <button
              onClick={toggleDarkMode}
              className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                darkMode ? 'bg-[var(--accent)]' : 'bg-[var(--border-input-focus)]'
              }`}
            >
              <div
                className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 shadow-md ${
                  darkMode ? 'translate-x-6' : 'translate-x-0'
                }`}
              ></div>
            </button>
          </div>
        </motion.div>

        {/* Logout */}
        <motion.button
          onClick={logout}
          className="w-full flex items-center justify-center gap-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 hover:border-red-500/40 font-bold py-4 rounded-xl transition duration-300 mt-8 shadow-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <FiLogOut size={20} />
          Sign Out
        </motion.button>
      </div>
    </motion.div>
  );
}