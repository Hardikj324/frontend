import { API_BASE_URL } from '../utils/constants';

const getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${localStorage.getItem('access_token')}`,
});

export const createAlert = async (alertData) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/alerts`,
      {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(alertData),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to create alert');
    }

    return await response.json();
  } catch (error) {
    console.error('Create Alert Error:', error);
    throw error;
  }
};

export const getAlerts = async () => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/alerts`,
      {
        method: 'GET',
        headers: getAuthHeaders(),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to fetch alerts');
    }

    return await response.json();
  } catch (error) {
    console.error('Get Alerts Error:', error);
    throw error;
  }
};

export const deleteAlert = async (alertId) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/alerts/${alertId}`,
      {
        method: 'DELETE',
        headers: getAuthHeaders(),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to delete alert');
    }

    return await response.json();
  } catch (error) {
    console.error('Delete Alert Error:', error);
    throw error;
  }
};