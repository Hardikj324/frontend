import { API_BASE_URL } from '../utils/constants';

const getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${localStorage.getItem('access_token')}`,
});

export const saveLocations = async (slot1, slot2, slot3, slot4) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/weather/save-locations`,
      {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          slot1: slot1 || null,
          slot2: slot2 || null,
          slot3: slot3 || null,
          slot4: slot4 || null,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to save locations');
    }

    return await response.json();
  } catch (error) {
    console.error('Save Locations Error:', error);
    throw error;
  }
};

export const getUserLocations = async () => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/weather/user-locations`,
      {
        method: 'GET',
        headers: getAuthHeaders(),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to fetch user locations');
    }

    return await response.json();
  } catch (error) {
    console.error('Get User Locations Error:', error);
    throw error;
  }
};