import { API_BASE_URL } from '../utils/constants';

const getAuthHeaders = () => ({
  'Content-Type': 'application/json',
  Authorization: `Bearer ${localStorage.getItem('access_token')}`,
});

export const getWeatherByCoordinates = async (latitude, longitude) => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/weather/current-location`,
      {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          current_latitude: latitude,
          current_longitude: longitude,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to fetch weather');
    }

    return await response.json();
  } catch (error) {
    console.error('Weather API Error:', error);
    throw error;
  }
};


export const getSavedLocationsWeather = async () => {
  try {
    const response = await fetch(
      `${API_BASE_URL}/weather/saved-locations`,
      {
        method: 'GET',
        headers: getAuthHeaders(),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to fetch saved locations');
    }

    return await response.json();
  } catch (error) {
    console.error('Saved Locations API Error:', error);
    throw error;
  }
};